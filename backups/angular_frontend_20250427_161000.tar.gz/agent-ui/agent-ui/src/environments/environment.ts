export const environment = {
  production: false,
  backendUrl: 'http://localhost:5001'
}; 