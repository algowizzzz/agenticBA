export const environment = {
  production: true,
  backendUrl: 'http://localhost:5001' // Change this for production deployment
}; 