import { Injectable, OnDestroy } from '@angular/core';
import { Socket, io } from 'socket.io-client';
import { Observable, Subject, BehaviorSubject } from 'rxjs';
import { environment } from '../../environments/environment';

export interface AgentStep {
  type: string;
  data: string;
  tool?: string;
}

export interface ConnectionStatus {
  connected: boolean;
  error?: string;
}

@Injectable({
  providedIn: 'root'
})
export class ChatService implements OnDestroy {
  private socket: Socket;
  private messageSubject = new Subject<{ content: string, sender: string }>();
  private thinkingSubject = new Subject<string>();
  private connectionStatusSubject = new BehaviorSubject<{ connected: boolean, error: string }>({ connected: true, error: '' });
  private currentThinkingSteps: string[] = [];
  
  constructor() {
    console.log('ChatService constructor running');
    try {
      this.socket = io(environment.backendUrl, {
        reconnection: true,
        reconnectionAttempts: 5,
        reconnectionDelay: 1000,
      });

      this.socket.on('connect', () => {
        console.log('Socket connected:', this.socket.id);
        this.connectionStatusSubject.next({ connected: true, error: '' });
      });

      this.socket.on('connection_success', (data) => {
        console.log('Connection success:', data);
      });

      this.socket.on('disconnect', () => {
        console.log('Socket disconnected');
        this.connectionStatusSubject.next({ connected: false, error: 'Disconnected from server' });
      });

      this.socket.on('connect_error', (error) => {
        console.error('Connection error:', error);
        this.connectionStatusSubject.next({ connected: false, error: 'Failed to connect to server' });
      });

      this.socket.on('agent_error', (error) => {
        console.error('Agent error:', error);
        this.thinkingSubject.next('');
        this.messageSubject.next({
          content: `Error: ${error.error}`,
          sender: 'agent'
        });
      });

      // New event handlers for more granular agent communication
      this.socket.on('thinking', (data) => {
        console.log('Thinking:', data);
        this.currentThinkingSteps = [];
        this.thinkingSubject.next('Thinking...');
      });

      this.socket.on('thought', (data) => {
        console.log('Thought:', data);
        this.currentThinkingSteps.push(`Thought: ${data.content}`);
        this.thinkingSubject.next(this.currentThinkingSteps.join('\n'));
      });

      this.socket.on('action', (data) => {
        console.log('Action:', data);
        this.currentThinkingSteps.push(`Action: ${data.tool}\n${data.content}`);
        this.thinkingSubject.next(this.currentThinkingSteps.join('\n'));
      });

      this.socket.on('observation', (data) => {
        console.log('Observation:', data);
        this.currentThinkingSteps.push(`Observation: ${data.content}`);
        this.thinkingSubject.next(this.currentThinkingSteps.join('\n'));
      });

      this.socket.on('agent_response', (data) => {
        console.log('Agent response:', data);
        // Clear thinking steps when we get the final response
        this.thinkingSubject.next('');
        this.messageSubject.next({
          content: data.content,
          sender: 'agent'
        });
      });

      // Legacy handler for agent_step events
      this.socket.on('agent_step', (step) => {
        console.log('Legacy agent step:', step);

        if (step.type === 'thought') {
          this.thinkingSubject.next(step.data);
        } else if (step.type === 'action') {
          this.thinkingSubject.next(`Action: ${step.tool}\nInput: ${step.data}`);
        } else if (step.type === 'observation') {
          this.thinkingSubject.next(`Observation: ${step.data}`);
        } else if (step.type === 'final_answer') {
          this.thinkingSubject.next('');
          this.messageSubject.next({
            content: step.data,
            sender: 'agent'
          });
        }
      });

    } catch (error) {
      console.error('Error initializing socket:', error);
      // Even with socket error, keep the UI usable for testing
      this.connectionStatusSubject.next({ connected: false, error: 'Error initializing socket connection' });
    }
  }
  
  /**
   * Send a message to the agent backend
   */
  sendMessage(message: string): void {
    console.log('Sending message:', message);
    
    // Add user message
    this.messageSubject.next({
      content: message,
      sender: 'user'
    });
    
    // Special handling for "hi" message to get immediate response
    if (message.toLowerCase() === 'hi' || message.toLowerCase() === 'hello') {
      // Simulate a response after a short delay
      setTimeout(() => {
        this.messageSubject.next({
          content: 'Hello! How can I assist you today?',
          sender: 'agent'
        });
      }, 500);
      return;
    }
    
    // For all other messages, try to use the server if connected
    try {
      if (this.socket && this.socket.connected) {
        // Send the message directly as a string, not as an object
        this.socket.emit('chat_message', message);
      } else {
        // For testing, provide a fallback response
        setTimeout(() => {
          this.messageSubject.next({
            content: 'I received your message: "' + message + '". However, I am currently operating in offline mode. For simple greetings like "hi" or "hello", I can respond, but for other queries, I need to be connected to the backend server.',
            sender: 'agent'
          });
        }, 1000);
      }
    } catch (error) {
      console.error('Error sending message:', error);
      this.messageSubject.next({
        content: 'Error sending message to server. Please try again later.',
        sender: 'agent'
      });
    }
  }
  
  getMessage(): Observable<{ content: string, sender: string }> {
    return this.messageSubject.asObservable();
  }
  
  getThinking(): Observable<string> {
    return this.thinkingSubject.asObservable();
  }
  
  getConnectionStatus(): Observable<{ connected: boolean, error: string }> {
    return this.connectionStatusSubject.asObservable();
  }
  
  ngOnDestroy(): void {
    console.log('>>> ChatService ngOnDestroy');
    if (this.socket) {
      console.log('>>> Disconnecting socket');
      this.socket.disconnect();
    }
  }
} 